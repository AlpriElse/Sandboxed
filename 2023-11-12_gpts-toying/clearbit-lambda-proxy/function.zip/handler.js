exports.handler = async (event) => {
  let queryParam = event.queryStringParameters?.query;

  if (queryParam === null) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: "Query parameter `query` is required",
      }),
    };
  }

  return {
    statusCode: 200,
    body: JSON.stringify({
      message: `Processed ${query}`,
    }),
  };
};
